# Build the project
	mvn clean install
# Run the project
	mvn spring-boot:run
	The project will run at http://localhost:8080

# Test
	Import this file in postman:
	Book.postman_collection.json
	You will then get all API endpoints